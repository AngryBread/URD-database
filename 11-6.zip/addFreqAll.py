import pandas as pd
import sys
import os

def process(file_name):
	path=""
	df = pd.read_csv(file_name)
	begin=0
	beginTime=df.at[1,"time_stamp"]
	endTime=beginTime+1000000

	for i in range(0,df.shape[0]):
    
		if df.at[i,"time_stamp"]<endTime:
			continue
		else:
			cnt=i-begin
			end2=i
			dict = {}
			for ii in range(begin,end2):
				df.at[ii,"frequent_all_actual"]=cnt
	            #每一个标签计算吞吐量
				key=df.at[ii,"epc"]
				if key in dict:
					dict[key]=dict[key]+1
				else:
					dict[key]=1
	                
			for ii in range(begin,end2):
				df.at[ii,"frequent_me_actual"]=dict[df.at[ii,"epc"]]
	    
		begin=i
		beginTime=df.at[begin,"time_stamp"]
		endTime=beginTime+1000000
	df.to_csv("new/"+os.path.splitext(file_name)[0]+"_addFreq.csv")
	print("已将 "+file_name+"处理，添加总吞吐量与分吞吐量-->"+os.path.splitext(file_name)[0]+"_addFreq.csv")

def file_name(file_dir):  
    L=[]  
    for root, dirs, files in os.walk(file_dir): 
      for file in files: 
        if os.path.splitext(file)[1] == '.csv': 
          L.append(file) 
    return L 

if __name__=='__main__':
	#print(sys.argv[1])
	#print(os.getcwd())  #保存路径
	os.mkdir("new\\")
	csv_file_list=file_name(os.getcwd())
	for filename in csv_file_list:
		print(filename)
		process(filename)
	

